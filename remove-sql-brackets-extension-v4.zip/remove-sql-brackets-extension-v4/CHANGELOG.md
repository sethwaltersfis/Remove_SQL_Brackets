# Changelog

## 4.0.0

- Added dialect-aware handling for SQL Server, PostgreSQL, Snowflake, MySQL, and ANSI-style quoting.
- Added MySQL backtick support.
- Added dialect-specific identifier safety rules for case preservation and wrapper removal.
- Added SQL Server double-quote and MySQL ANSI_QUOTES compatibility switches.
- Added preserveBacktickAliases setting.
