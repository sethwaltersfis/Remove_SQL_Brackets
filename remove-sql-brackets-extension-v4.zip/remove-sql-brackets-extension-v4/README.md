# Remove SQL Brackets - Version 4

Version 4 adds **dialect-aware handling** for SQL Server, PostgreSQL, Snowflake, MySQL-style backticks, and generic ANSI-style double-quoted identifiers.

## Commands

- `Remove SQL Brackets: Remove Brackets (Whole Document)`
- `Remove SQL Brackets: Remove Brackets (Selection)`

Both commands are available from the editor right-click menu.

## New in Version 4

### Dialect-aware behavior

Set `removeSqlBrackets.dialect` to one of:

- `sqlserver`
- `postgresql`
- `snowflake`
- `mysql`
- `ansi`

### Dialect rules implemented

- **SQL Server**
  - Removes square brackets when safe.
  - Can also process double-quoted identifiers when `removeSqlBrackets.sqlServerTreatDoubleQuotesAsIdentifiers` is enabled.
- **PostgreSQL**
  - Processes double-quoted identifiers.
  - Only removes double quotes when the identifier is safe *and already lowercase*, because unquoted PostgreSQL identifiers fold to lowercase.
- **Snowflake**
  - Processes double-quoted identifiers.
  - Only removes double quotes when the identifier is safe *and already uppercase*, because unquoted Snowflake identifiers resolve as uppercase.
- **MySQL**
  - Processes backtick-quoted identifiers.
  - Can also process double-quoted identifiers when `removeSqlBrackets.mysqlAnsiQuotes` is enabled.
- **ANSI**
  - Processes double-quoted identifiers using lowercase-safe rules.

### Alias preservation settings

- `removeSqlBrackets.preserveSquareBracketAliases`
- `removeSqlBrackets.preserveDoubleQuotedAliases`
- `removeSqlBrackets.preserveBacktickAliases`

These work for aliases with `AS` and aliases without `AS`.

## Example

### SQL Server

```sql
SELECT [CustomerID] AS [Customer Alias]
FROM [dbo].[Customers];
```

### PostgreSQL

```sql
SELECT "customer_id" "customer_alias"
FROM public.customers;
```

### Snowflake

```sql
SELECT "CUSTOMER_ID" "CUSTOMER_ALIAS"
FROM PUBLIC.CUSTOMERS;
```

### MySQL

```sql
SELECT `customer_id` `customer_alias`
FROM `customers`;
```

## Build

```bash
npm install
npm run compile
```

## Package

```bash
npx @vscode/vsce package
```
