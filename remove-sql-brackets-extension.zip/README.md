## Commands

- `Remove SQL Brackets: Remove Brackets (Whole Document)`
- `Remove SQL Brackets: Remove Brackets (Selection)`

Both commands are available from the editor right-click menu.
