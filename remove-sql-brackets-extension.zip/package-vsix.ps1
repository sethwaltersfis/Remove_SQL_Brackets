param(
    [switch]$InstallDependencies
)

if ($InstallDependencies) {
    npm install
}

Write-Host "Preparing to build packaged extension..."
npm install -g @vscode/vsce
npm install
npx @vscode/vsce package