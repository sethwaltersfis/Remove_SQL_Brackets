import * as vscode from 'vscode';

type Mode = 'normal' | 'singleQuote' | 'doubleQuoteLiteral' | 'lineComment' | 'blockComment';
type WrapperType = 'square' | 'doubleQuote' | 'curly' | 'backtick';
type Dialect = 'sqlserver' | 'postgresql' | 'snowflake' | 'mysql' | 'ansi';

type SignificantToken = {
  kind: 'word' | 'symbol' | 'number' | 'none';
  text: string;
  upper: string;
};

type WrapperMatch = {
  content: string;
  end: number;
  type: WrapperType;
};

const RESERVED_WORDS = new Set<string>([
  'ADD','ALL','ALTER','AND','ANY','AS','ASC','AUTHORIZATION','BACKUP','BEGIN','BETWEEN','BREAK','BROWSE','BULK','BY',
  'CASCADE','CASE','CHECK','CHECKPOINT','CLOSE','CLUSTERED','COALESCE','COLLATE','COLUMN','COMMIT','COMPUTE','CONSTRAINT',
  'CONTAINS','CONTAINSTABLE','CONTINUE','CONVERT','CREATE','CROSS','CURRENT','CURRENT_DATE','CURRENT_TIME','CURRENT_TIMESTAMP',
  'CURRENT_USER','CURSOR','DATABASE','DBCC','DEALLOCATE','DECLARE','DEFAULT','DELETE','DENY','DESC','DISK','DISTINCT','DISTRIBUTED',
  'DOUBLE','DROP','DUMP','ELSE','END','ERRLVL','ESCAPE','EXCEPT','EXEC','EXECUTE','EXISTS','EXTERNAL','FETCH','FILE','FILLFACTOR',
  'FOR','FOREIGN','FREETEXT','FREETEXTTABLE','FROM','FULL','FUNCTION','GOTO','GRANT','GROUP','HAVING','HOLDLOCK','IDENTITY',
  'IDENTITY_INSERT','IDENTITYCOL','IF','IN','INDEX','INNER','INSERT','INTERSECT','INTO','IS','JOIN','KEY','KILL','LEFT','LIKE',
  'LINENO','LOAD','MERGE','NATIONAL','NOCHECK','NONCLUSTERED','NOT','NULL','NULLIF','OF','OFF','OFFSETS','ON','OPEN','OPENDATASOURCE',
  'OPENQUERY','OPENROWSET','OPENXML','OPTION','OR','ORDER','OUTER','OVER','PERCENT','PIVOT','PLAN','PRECISION','PRIMARY','PRINT',
  'PROC','PROCEDURE','PUBLIC','RAISERROR','READ','READTEXT','RECONFIGURE','REFERENCES','REPLICATION','RESTORE','RESTRICT','RETURN',
  'REVERT','REVOKE','RIGHT','ROLLBACK','ROWCOUNT','ROWGUIDCOL','RULE','SAVE','SCHEMA','SECURITYAUDIT','SELECT','SEMANTICKEYPHRASETABLE',
  'SEMANTICSIMILARITYDETAILSTABLE','SEMANTICSIMILARITYTABLE','SESSION_USER','SET','SETUSER','SHUTDOWN','SOME','STATISTICS','SYSTEM_USER',
  'TABLE','TABLESAMPLE','TEXTSIZE','THEN','TO','TOP','TRAN','TRANSACTION','TRIGGER','TRUNCATE','TRY_CONVERT','TSEQUAL','UNION','UNIQUE',
  'UNPIVOT','UPDATE','UPDATETEXT','USE','USER','VALUES','VARYING','VIEW','WAITFOR','WHEN','WHERE','WHILE','WITH','WITHIN','WRITETEXT'
]);

const CLAUSE_BOUNDARY_WORDS = new Set<string>([
  'FROM','WHERE','GROUP','ORDER','HAVING','UNION','EXCEPT','INTERSECT','JOIN','INNER','LEFT','RIGHT','FULL','CROSS','OUTER',
  'ON','WHEN','ELSE','END','OVER','INTO','VALUES','SET','LIMIT','OFFSET','QUALIFY'
]);

export function activate(context: vscode.ExtensionContext): void {
  const removeDocument = vscode.commands.registerTextEditorCommand(
    'removeSqlBrackets.removeBracketsDocument',
    async (editor) => {
      const fullRange = new vscode.Range(
        editor.document.positionAt(0),
        editor.document.positionAt(editor.document.getText().length)
      );
      await applyReplacement(editor, fullRange, editor.document.getText());
    }
  );

  const removeSelection = vscode.commands.registerTextEditorCommand(
    'removeSqlBrackets.removeBracketsSelection',
    async (editor) => {
      const selections = editor.selections.filter((selection) => !selection.isEmpty);
      if (selections.length === 0) {
        vscode.window.showInformationMessage('Remove SQL Brackets: No text is selected.');
        return;
      }

      await editor.edit((editBuilder) => {
        const orderedSelections = [...selections].sort(
          (a, b) => editor.document.offsetAt(b.start) - editor.document.offsetAt(a.start)
        );

        for (const selection of orderedSelections) {
          const original = editor.document.getText(selection);
          editBuilder.replace(selection, processSql(original));
        }
      });
    }
  );

  context.subscriptions.push(removeDocument, removeSelection);
}

async function applyReplacement(editor: vscode.TextEditor, range: vscode.Range, text: string): Promise<void> {
  const updated = processSql(text);
  await editor.edit((editBuilder) => {
    editBuilder.replace(range, updated);
  });
}

function processSql(input: string): string {
  const config = vscode.workspace.getConfiguration('removeSqlBrackets');
  const dialect = (config.get<string>('dialect', 'sqlserver') as Dialect);
  const includeCurlyBraces = config.get<boolean>('includeCurlyBraces', false);
  const preserveInsideStringsAndComments = config.get<boolean>('preserveInsideStringsAndComments', true);
  const sqlServerTreatDoubleQuotesAsIdentifiers = config.get<boolean>('sqlServerTreatDoubleQuotesAsIdentifiers', false);
  const mysqlAnsiQuotes = config.get<boolean>('mysqlAnsiQuotes', false);
  const preserveSquareBracketAliases = config.get<boolean>('preserveSquareBracketAliases', false);
  const preserveDoubleQuotedAliases = config.get<boolean>('preserveDoubleQuotedAliases', true);
  const preserveBacktickAliases = config.get<boolean>('preserveBacktickAliases', true);

  let out = '';
  let i = 0;
  let mode: Mode = 'normal';

  while (i < input.length) {
    const ch = input[i];
    const next = charAt(input, i + 1);

    if (!preserveInsideStringsAndComments) {
      const wrapper = tryConsumeWrapper(input, i, dialect, includeCurlyBraces, sqlServerTreatDoubleQuotesAsIdentifiers, mysqlAnsiQuotes);
      if (wrapper) {
        out += normalizeWrappedIdentifier(
          input,
          wrapper.content,
          wrapper.type,
          dialect,
          i,
          wrapper.end,
          preserveSquareBracketAliases,
          preserveDoubleQuotedAliases,
          preserveBacktickAliases
        );
        i = wrapper.end;
        continue;
      }

      out += ch;
      i += 1;
      continue;
    }

    if (mode === 'normal') {
      if (ch === '-' && next === '-') {
        out += ch + next;
        i += 2;
        mode = 'lineComment';
        continue;
      }
      if (ch === '/' && next === '*') {
        out += ch + next;
        i += 2;
        mode = 'blockComment';
        continue;
      }
      if (ch === '\'') {
        out += ch;
        i += 1;
        mode = 'singleQuote';
        continue;
      }

      const wrapper = tryConsumeWrapper(input, i, dialect, includeCurlyBraces, sqlServerTreatDoubleQuotesAsIdentifiers, mysqlAnsiQuotes);
      if (wrapper) {
        out += normalizeWrappedIdentifier(
          input,
          wrapper.content,
          wrapper.type,
          dialect,
          i,
          wrapper.end,
          preserveSquareBracketAliases,
          preserveDoubleQuotedAliases,
          preserveBacktickAliases
        );
        i = wrapper.end;
        continue;
      }

      if (ch === '"') {
        out += ch;
        i += 1;
        mode = 'doubleQuoteLiteral';
        continue;
      }

      out += ch;
      i += 1;
      continue;
    }

    if (mode === 'singleQuote') {
      out += ch;
      i += 1;
      if (ch === '\'' && next === '\'') {
        out += next;
        i += 1;
        continue;
      }
      if (ch === '\'') {
        mode = 'normal';
      }
      continue;
    }

    if (mode === 'doubleQuoteLiteral') {
      out += ch;
      i += 1;
      if (ch === '"' && next === '"') {
        out += next;
        i += 1;
        continue;
      }
      if (ch === '"') {
        mode = 'normal';
      }
      continue;
    }

    if (mode === 'lineComment') {
      out += ch;
      i += 1;
      if (ch === '\n') {
        mode = 'normal';
      }
      continue;
    }

    out += ch;
    i += 1;
    if (mode === 'blockComment' && ch === '*' && next === '/') {
      out += next;
      i += 1;
      mode = 'normal';
    }
  }

  return out;
}

function tryConsumeWrapper(
  text: string,
  start: number,
  dialect: Dialect,
  includeCurlyBraces: boolean,
  sqlServerTreatDoubleQuotesAsIdentifiers: boolean,
  mysqlAnsiQuotes: boolean
): WrapperMatch | null {
  const ch = text[start];

  if (ch === '[' && dialect === 'sqlserver') {
    const consumed = consumeBracketedIdentifier(text, start);
    return consumed ? { ...consumed, type: 'square' } : null;
  }

  if (ch === '`' && dialect === 'mysql') {
    const consumed = consumeBacktickIdentifier(text, start);
    return consumed ? { ...consumed, type: 'backtick' } : null;
  }

  if (ch === '"' && shouldTreatDoubleQuotesAsIdentifier(dialect, sqlServerTreatDoubleQuotesAsIdentifiers, mysqlAnsiQuotes)) {
    const consumed = consumeDoubleQuotedIdentifier(text, start);
    return consumed ? { ...consumed, type: 'doubleQuote' } : null;
  }

  if (includeCurlyBraces && ch === '{') {
    const consumed = consumeGenericWrapper(text, start, '{', '}');
    return consumed ? { ...consumed, type: 'curly' } : null;
  }

  return null;
}

function shouldTreatDoubleQuotesAsIdentifier(
  dialect: Dialect,
  sqlServerTreatDoubleQuotesAsIdentifiers: boolean,
  mysqlAnsiQuotes: boolean
): boolean {
  if (dialect === 'postgresql' || dialect === 'snowflake' || dialect === 'ansi') {
    return true;
  }
  if (dialect === 'sqlserver') {
    return sqlServerTreatDoubleQuotesAsIdentifiers;
  }
  if (dialect === 'mysql') {
    return mysqlAnsiQuotes;
  }
  return false;
}

function consumeBracketedIdentifier(text: string, start: number): { content: string; end: number } | null {
  if (text[start] !== '[') {
    return null;
  }
  let i = start + 1;
  let content = '';
  while (i < text.length) {
    const ch = text[i];
    const next = charAt(text, i + 1);
    if (ch === ']' && next === ']') {
      content += ']';
      i += 2;
      continue;
    }
    if (ch === ']') {
      return { content, end: i + 1 };
    }
    content += ch;
    i += 1;
  }
  return null;
}

function consumeDoubleQuotedIdentifier(text: string, start: number): { content: string; end: number } | null {
  if (text[start] !== '"') {
    return null;
  }
  let i = start + 1;
  let content = '';
  while (i < text.length) {
    const ch = text[i];
    const next = charAt(text, i + 1);
    if (ch === '"' && next === '"') {
      content += '"';
      i += 2;
      continue;
    }
    if (ch === '"') {
      return { content, end: i + 1 };
    }
    content += ch;
    i += 1;
  }
  return null;
}

function consumeBacktickIdentifier(text: string, start: number): { content: string; end: number } | null {
  if (text[start] !== '`') {
    return null;
  }
  let i = start + 1;
  let content = '';
  while (i < text.length) {
    const ch = text[i];
    const next = charAt(text, i + 1);
    if (ch === '`' && next === '`') {
      content += '`';
      i += 2;
      continue;
    }
    if (ch === '`') {
      return { content, end: i + 1 };
    }
    content += ch;
    i += 1;
  }
  return null;
}

function consumeGenericWrapper(text: string, start: number, open: string, close: string): { content: string; end: number } | null {
  if (text[start] !== open) {
    return null;
  }
  const end = text.indexOf(close, start + 1);
  if (end === -1) {
    return null;
  }
  return { content: text.slice(start + 1, end), end: end + 1 };
}

function normalizeWrappedIdentifier(
  fullText: string,
  content: string,
  wrapperType: WrapperType,
  dialect: Dialect,
  start: number,
  end: number,
  preserveSquareBracketAliases: boolean,
  preserveDoubleQuotedAliases: boolean,
  preserveBacktickAliases: boolean
): string {
  if (
    shouldPreserveAliasWrapper(
      fullText,
      start,
      end,
      wrapperType,
      preserveSquareBracketAliases,
      preserveDoubleQuotedAliases,
      preserveBacktickAliases
    )
  ) {
    return rewrap(content, wrapperType);
  }

  return canRemoveIdentifierWrapper(content, dialect, wrapperType)
    ? content
    : rewrap(content, wrapperType);
}

function shouldPreserveAliasWrapper(
  fullText: string,
  start: number,
  end: number,
  wrapperType: WrapperType,
  preserveSquareBracketAliases: boolean,
  preserveDoubleQuotedAliases: boolean,
  preserveBacktickAliases: boolean
): boolean {
  if (wrapperType === 'square' && !preserveSquareBracketAliases) {
    return false;
  }
  if (wrapperType === 'doubleQuote' && !preserveDoubleQuotedAliases) {
    return false;
  }
  if (wrapperType === 'backtick' && !preserveBacktickAliases) {
    return false;
  }
  if (wrapperType === 'curly') {
    return false;
  }
  return isAliasContext(fullText, start, end);
}

function isAliasContext(text: string, start: number, end: number): boolean {
  const previousToken = readPreviousSignificantToken(text, start);
  const nextToken = readNextSignificantToken(text, end);

  if (previousToken.kind === 'word' && previousToken.upper === 'AS') {
    return true;
  }

  if (!isImplicitAliasPreviousToken(previousToken)) {
    return false;
  }

  if (!isAliasBoundaryNextToken(nextToken)) {
    return false;
  }

  return true;
}

function isImplicitAliasPreviousToken(token: SignificantToken): boolean {
  if (token.kind === 'word' || token.kind === 'number') {
    return true;
  }
  if (token.kind !== 'symbol') {
    return false;
  }
  return token.text === ']' || token.text === ')' || token.text === '\'' || token.text === '"' || token.text === '`';
}

function isAliasBoundaryNextToken(token: SignificantToken): boolean {
  if (token.kind === 'none') {
    return true;
  }
  if (token.kind === 'symbol') {
    return token.text === ',' || token.text === ';' || token.text === ')';
  }
  if (token.kind === 'word') {
    return CLAUSE_BOUNDARY_WORDS.has(token.upper);
  }
  return false;
}

function readPreviousSignificantToken(text: string, position: number): SignificantToken {
  let i = position - 1;
  while (i >= 0 && /\s/.test(text[i])) {
    i -= 1;
  }
  if (i < 0) {
    return { kind: 'none', text: '', upper: '' };
  }

  const ch = text[i];
  if (/[A-Za-z_]/.test(ch)) {
    let start = i;
    while (start - 1 >= 0 && /[A-Za-z0-9_\$]/.test(text[start - 1])) {
      start -= 1;
    }
    const word = text.slice(start, i + 1);
    return { kind: 'word', text: word, upper: word.toUpperCase() };
  }

  if (/[0-9]/.test(ch)) {
    let start = i;
    while (start - 1 >= 0 && /[0-9.]/.test(text[start - 1])) {
      start -= 1;
    }
    const numberText = text.slice(start, i + 1);
    return { kind: 'number', text: numberText, upper: numberText.toUpperCase() };
  }

  return { kind: 'symbol', text: ch, upper: ch.toUpperCase() };
}

function readNextSignificantToken(text: string, position: number): SignificantToken {
  let i = position;
  while (i < text.length && /\s/.test(text[i])) {
    i += 1;
  }
  if (i >= text.length) {
    return { kind: 'none', text: '', upper: '' };
  }

  const ch = text[i];
  if (/[A-Za-z_]/.test(ch)) {
    let end = i + 1;
    while (end < text.length && /[A-Za-z0-9_\$]/.test(text[end])) {
      end += 1;
    }
    const word = text.slice(i, end);
    return { kind: 'word', text: word, upper: word.toUpperCase() };
  }

  if (/[0-9]/.test(ch)) {
    let end = i + 1;
    while (end < text.length && /[0-9.]/.test(text[end])) {
      end += 1;
    }
    const numberText = text.slice(i, end);
    return { kind: 'number', text: numberText, upper: numberText.toUpperCase() };
  }

  return { kind: 'symbol', text: ch, upper: ch.toUpperCase() };
}

function canRemoveIdentifierWrapper(identifier: string, dialect: Dialect, wrapperType: WrapperType): boolean {
  if (identifier.length === 0) {
    return false;
  }

  switch (dialect) {
    case 'sqlserver':
      if (wrapperType !== 'square' && wrapperType !== 'doubleQuote' && wrapperType !== 'curly') {
        return false;
      }
      return isSafeSqlServerIdentifier(identifier);

    case 'postgresql':
    case 'ansi':
      if (wrapperType !== 'doubleQuote' && wrapperType !== 'curly') {
        return false;
      }
      return isSafePostgreSqlIdentifier(identifier);

    case 'snowflake':
      if (wrapperType !== 'doubleQuote' && wrapperType !== 'curly') {
        return false;
      }
      return isSafeSnowflakeIdentifier(identifier);

    case 'mysql':
      if (wrapperType !== 'backtick' && wrapperType !== 'doubleQuote' && wrapperType !== 'curly') {
        return false;
      }
      return isSafeMySqlIdentifier(identifier);

    default:
      return false;
  }
}

function isSafeSqlServerIdentifier(identifier: string): boolean {
  if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(identifier)) {
    return false;
  }
  return !RESERVED_WORDS.has(identifier.toUpperCase());
}

function isSafePostgreSqlIdentifier(identifier: string): boolean {
  if (!/^[A-Za-z_][A-Za-z0-9_\$]*$/.test(identifier)) {
    return false;
  }
  if (identifier !== identifier.toLowerCase()) {
    return false;
  }
  return !RESERVED_WORDS.has(identifier.toUpperCase());
}

function isSafeSnowflakeIdentifier(identifier: string): boolean {
  if (!/^[A-Za-z_][A-Za-z0-9_\$]*$/.test(identifier)) {
    return false;
  }
  if (identifier !== identifier.toUpperCase()) {
    return false;
  }
  return !RESERVED_WORDS.has(identifier.toUpperCase());
}

function isSafeMySqlIdentifier(identifier: string): boolean {
  if (!/^[A-Za-z0-9_\$]+$/.test(identifier)) {
    return false;
  }
  if (/^[0-9]+$/.test(identifier)) {
    return false;
  }
  return !RESERVED_WORDS.has(identifier.toUpperCase());
}

function rewrap(content: string, wrapperType: WrapperType): string {
  switch (wrapperType) {
    case 'square':
      return `[${content.replace(/]/g, ']]')}]`;
    case 'doubleQuote':
      return `"${content.replace(/"/g, '""')}"`;
    case 'backtick':
      return `\`${content.replace(/`/g, '``')}\``;
    case 'curly':
      return `{${content}}`;
    default:
      return content;
  }
}

function charAt(text: string, index: number): string {
  return index >= 0 && index < text.length ? text[index] : '';
}

export function deactivate(): void {
  // no-op
}
